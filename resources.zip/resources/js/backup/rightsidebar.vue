<template>
<div>
    <nav aria-label="Secondary navigation" aria-hidden="true" class="bd-toc col-xl-2 d-none d-xl-block">
            
            <ul class="nav section-nav flex-column"><!----> </ul>
        
        </nav>
        </div>
</template>

<script>
    export default {
        
    }
</script>
<style scoped>

</style>